﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class asp_showPro1 : System.Web.UI.Page
{
    SqlConnection conn;
    SqlCommand scmd;
    string constr = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\user.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
    int BID;
    int uid;
    string bname;
    double bprice;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
    {
        if (Session["un"] == null)
        {
            Response.Write("<script type='text/javascript' language='javascript'>alert('请先登录');</script>");
            Server.Transfer("login.aspx");
        }
     
        if (e.CommandName == "Add") {
            BID = Convert.ToInt32(e.CommandArgument);
            string uname = Session["un"].ToString();
            conn = new SqlConnection(constr);
            try
            {
                conn.Open();
                string sql = "select UserID from uaer where Username='" + uname + "'";
                scmd = new SqlCommand(sql, conn);
                SqlDataReader sdr = scmd.ExecuteReader();
                if (sdr.Read())
                {
                    uid = Convert.ToInt32(sdr[0]);
                }
                sdr.Close();
                sql = "select * from products where PID=" + BID + "";
                scmd = new SqlCommand(sql, conn);
                sdr = scmd.ExecuteReader();
                if (sdr.Read())
                {
                    bname = sdr["Pname"].ToString();
                    bprice = Convert.ToDouble(sdr["SMprice"]);
                }
                sdr.Close();
                sql = "select PID from Carts where UserID=" + uid;
                scmd.CommandText = sql;
                sdr = scmd.ExecuteReader();
                sql = "insert into Carts(UserID,PID,Pname,Price,Num) values(" + uid + ","
                + BID + ",'" + bname + "'," + bprice + ",1)";
                while (sdr.Read())
                {
                    if (BID == Convert.ToInt32(sdr[0]))
                    {
                        sql = "update Carts set Num=Num+1 where UserID= " + uid + "and PID=" + BID;
                        break;
                    }
                }
                sdr.Close();
                scmd.CommandText = sql;
                int flag = scmd.ExecuteNonQuery();
                if (flag > 0)
                {
                    Response.Write("<script type='text/javascript' language='javascript'>alert('成功加入购物车！');</script>");
                }
                else
                {
                    Response.Write("<script type='text/javascript' language='javascript'>alert('加入购物车失败！');</script>");
                }
                conn.Close();
            }
            catch (Exception ex) {
                Response.Write(ex.Message);
            }
            
        }
    }
}