﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class aspx_Welcome : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["un"] != null)
            Label1.Text = "在线用户：" + Session["un"];
        else
        {
            Response.Write("<script type='Text/javascript'>alert('你没有登录，请登录！')</script>");
            Server.Transfer("login.aspx");
        }
    }

}