﻿
Partial Class aspx_lbn
    Inherits System.Web.UI.Page

End Class
