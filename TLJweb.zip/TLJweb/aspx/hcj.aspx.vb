﻿
Partial Class aspx_hcj
    Inherits System.Web.UI.Page

End Class
