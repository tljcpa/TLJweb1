﻿
Partial Class aspx_byjx
    Inherits System.Web.UI.Page

End Class
