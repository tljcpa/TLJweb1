﻿
Partial Class aspx_zths
    Inherits System.Web.UI.Page

End Class
