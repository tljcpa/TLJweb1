﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class aspx_ShopingCar : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
         try
        {
            Label1.Text = "购物车信息";
            int uid = 0;
            if (Session["un"] == null)
            {
                Response.Write("<script language='javascript' type='script/javascript'>alert('没登录，请登录！')</script>");
                Server.Transfer("login.aspx");
            }
            string uname = Session["un"].ToString();
            string sql = "select UserID from uaer where Username='" + uname + "'";

            string strcon = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\user.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
            SqlConnection conn = new SqlConnection(strcon);
            conn.Open();
            SqlCommand scmd = new SqlCommand(sql, conn);
            SqlDataReader sdr = scmd.ExecuteReader();
            if (sdr.Read())
            {
                uid = Convert.ToInt32(sdr[0]);
            }
            sdr.Close();
            sql = "select * from Carts where UserID=" + uid;
            SqlDataAdapter msdapt = new SqlDataAdapter(sql, conn);
            DataSet ds = new DataSet();
            msdapt.Fill(ds, "Carts");
            GridView1.DataSource = ds.Tables["Carts"];
            GridView1.DataBind();
            conn.Close();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
   
}